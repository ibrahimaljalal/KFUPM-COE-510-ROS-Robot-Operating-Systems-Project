#!/usr/bin/env python3

import rospy
from ibrahim_project.msg import message_detection

def callback(data_red):
    rospy.loginfo("Red subscriber data:")
    rospy.loginfo("x_segments = "+str(data_red.x_segments))
    rospy.loginfo("y_segments = "+str(data_red.y_segments))
    rospy.loginfo("x_num = "+str(data_red.x_num))
    rospy.loginfo("y_num = "+str(data_red.y_num))
    print("\n")
    



rospy.init_node('redSubscriberNode', anonymous=True)

rospy.Subscriber("redTopic", message_detection, callback)

rospy.spin()