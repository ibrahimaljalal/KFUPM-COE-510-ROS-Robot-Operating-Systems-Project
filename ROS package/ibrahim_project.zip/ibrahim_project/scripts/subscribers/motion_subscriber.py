#!/usr/bin/env python3

import rospy
from ibrahim_project.msg import message_detection

def callback(data_motion):
    rospy.loginfo("Motion subscriber data:")
    rospy.loginfo("x_segments = "+str(data_motion.x_segments))
    rospy.loginfo("y_segments = "+str(data_motion.y_segments))
    rospy.loginfo("x_num = "+str(data_motion.x_num))
    rospy.loginfo("y_num = "+str(data_motion.y_num))
    print("\n")
    



rospy.init_node('motionSubscriberNode', anonymous=True)

rospy.Subscriber("motionTopic", message_detection, callback)

rospy.spin()