#!/usr/bin/env python3

import rospy
from ibrahim_project.msg import message_detection

def callback(data_blue):
    rospy.loginfo("Blue subscriber data:")
    rospy.loginfo("x_segments = "+str(data_blue.x_segments))
    rospy.loginfo("y_segments = "+str(data_blue.y_segments))
    rospy.loginfo("x_num = "+str(data_blue.x_num))
    rospy.loginfo("y_num = "+str(data_blue.y_num))
    print("\n")



rospy.init_node('blueSubscriberNode', anonymous=True)

rospy.Subscriber("blueTopic", message_detection, callback)

rospy.spin()