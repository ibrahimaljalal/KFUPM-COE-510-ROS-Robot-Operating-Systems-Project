#!/usr/bin/env python3

from __future__ import print_function
import rospy
from ibrahim_project.srv import*


def show():
    rospy.wait_for_service('blueService')

    try:
        blueService = rospy.ServiceProxy('blueService', service_detection)
        blueResponse = blueService()
        print("x_segments = "+str(blueResponse.x_segments))
        print("y_segments = "+str(blueResponse.y_segments))
        print("x_num = "+str(blueResponse.x_num))
        print("y_num = "+str(blueResponse.y_num))

    except rospy.ServiceException as e:
        print("Service call failed: %s"%e)




if __name__=="__main__":
    show()

