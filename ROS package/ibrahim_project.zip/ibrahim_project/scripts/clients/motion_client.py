#!/usr/bin/env python3

from __future__ import print_function
import rospy
from ibrahim_project.srv import*


def show():
    rospy.wait_for_service('motionService')

    try:
        motionService = rospy.ServiceProxy('motionService', service_detection)
        motionResponse = motionService()
        print("x_segments = "+str(motionResponse.x_segments))
        print("y_segments = "+str(motionResponse.y_segments))
        print("x_num = "+str(motionResponse.x_num))
        print("y_num = "+str(motionResponse.y_num))

    except rospy.ServiceException as e:
        print("Service call failed: %s"%e)




if __name__=="__main__":
    show()

